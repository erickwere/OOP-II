for(int i = 0; i < 10;)
{
    cout << i++ << "\n";
}
for(int i = 0; i < 10;)
{
    cout << ++i << "\n";
}
