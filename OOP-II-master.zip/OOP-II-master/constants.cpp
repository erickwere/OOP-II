#include <iostream>

using namespace std;

#define PI 3.14159
#define NNEWLINE '\n'

int main()
{
    double r = 5.0;
    double circle;

    circle = 2 * PI * r;
    cout << circle << '\n';
    
    return 0;
}