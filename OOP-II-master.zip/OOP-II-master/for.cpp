#include <iostream>
using namespace std;

int main ()
{
    for(int x = 0; x = x + 1;)
        cout << x << "\n";

    return 0;
}