#include <iostream>

using namespace std ;

int main()

{
    int N;
    cin >> N;
    do
    {
            cout <<"Hello,world!\n";
    }
    while(--N > 0);
    return 0;
}