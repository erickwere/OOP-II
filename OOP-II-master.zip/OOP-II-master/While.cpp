#include <iostream>
using namespace std;

int main() {
    int x = 0;

    while(x < 10)
        x = x + 1;

    cout << "x is " << x << "\n";

    return 0;
}

